/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principal;

import Clases.Personas;
import Formulario.FormularioPersona;

/**
 *
 * @author Sala de Sistemas
 */
public class main {


    public static void main(String[] args) {
       
        FormularioPersona F = new FormularioPersona ();
        F.setVisible(true);
       
        
    }
    
}
